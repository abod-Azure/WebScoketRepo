using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using CryptoOrderBook.Services;

namespace CryptoOrderBook.Controllers;

public class OrderBookController : Controller
{
    private readonly BinanceOrderBookService _binance;

    public OrderBookController(BinanceOrderBookService binance)
        => _binance = binance;

    public IActionResult Index() => View();

    // WebSocket endpoint: GET /OrderBook/Stream?symbol=btcusdt
    [HttpGet("/OrderBook/Stream")]
    public async Task Stream(string symbol = "btcusdt", CancellationToken ct = default)
    {
        if (!HttpContext.WebSockets.IsWebSocketRequest)
        {
            HttpContext.Response.StatusCode = 400;
            return;
        }

        using var browserWs = await HttpContext.WebSockets.AcceptWebSocketAsync();

        var opts = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        try
        {
            await foreach (var snap in _binance.StreamAsync(symbol, ct))
            {
                if (browserWs.State != WebSocketState.Open) break;

                var json  = JsonSerializer.Serialize(snap, opts);
                var bytes = Encoding.UTF8.GetBytes(json);
                await browserWs.SendAsync(bytes, WebSocketMessageType.Text, true, ct);
            }
        }
        catch (OperationCanceledException) { }
        catch (WebSocketException) { }
        finally
        {
            if (browserWs.State == WebSocketState.Open)
                await browserWs.CloseAsync(WebSocketCloseStatus.NormalClosure, "done", CancellationToken.None);
        }
    }
}
