# Crypto Order Book — Live WebSocket Stream

**Course:** Advanced Web Development - Streaming
**Student:** [Your Full Name]

## Demo Video
https://youtu.be/YOUR_LINK_HERE

## Streaming Details
- **Technique:** WebSocket (bidirectional) — server bridges Binance WS to browser WS
- **What is streamed:** Live order book depth (top 15 bids/asks) for BTC, ETH, BNB, SOL — updated every 100ms
- **Smart idea:** Arbitrage/spread detection — alerts when spread widens beyond 1.5x the rolling average

## How to Run
```bash
dotnet restore
dotnet run
```
Open http://localhost:5000

## .gitignore
```
bin/
obj/
*.user
appsettings.Development.json
```
