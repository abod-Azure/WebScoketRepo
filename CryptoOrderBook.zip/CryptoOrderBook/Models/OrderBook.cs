namespace CryptoOrderBook.Models;

public class OrderBookEntry
{
    public decimal Price  { get; set; }
    public decimal Amount { get; set; }
    public decimal Total  { get; set; }   // cumulative
}

public class OrderBookSnapshot
{
    public string Symbol       { get; set; } = "";
    public List<OrderBookEntry> Bids { get; set; } = [];
    public List<OrderBookEntry> Asks { get; set; } = [];
    public decimal LastPrice   { get; set; }
    public decimal Spread      { get; set; }
    public decimal SpreadPct   { get; set; }
    public DateTime UpdatedAt  { get; set; }

    // Smart Idea: arbitrage signal
    public ArbitrageSignal? Arbitrage { get; set; }
}

public class ArbitrageSignal
{
    public string Description { get; set; } = "";
    public decimal ProfitPct  { get; set; }
    public bool    IsAlert    { get; set; }
}
