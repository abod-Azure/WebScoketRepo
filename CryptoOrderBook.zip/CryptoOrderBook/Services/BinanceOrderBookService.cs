using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using CryptoOrderBook.Models;

namespace CryptoOrderBook.Services;

public class BinanceOrderBookService
{
    private readonly ILogger<BinanceOrderBookService> _logger;

    // Last known prices per symbol for arbitrage detection
    private static readonly Dictionary<string, decimal> _lastBestBid = new();
    private static readonly Dictionary<string, decimal> _lastBestAsk = new();

    public BinanceOrderBookService(ILogger<BinanceOrderBookService> logger)
        => _logger = logger;

    public async IAsyncEnumerable<OrderBookSnapshot> StreamAsync(
        string symbol,
        [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default)
    {
        var url = $"wss://stream.binance.com:9443/ws/{symbol.ToLower()}@depth20@100ms";

        while (!ct.IsCancellationRequested)
        {
            using var ws = new ClientWebSocket();
            ws.Options.KeepAliveInterval = TimeSpan.FromSeconds(20);

            OrderBookSnapshot? snapshot = null;

            try
            {
                await ws.ConnectAsync(new Uri(url), ct);
                _logger.LogInformation("Connected to Binance WS for {symbol}", symbol);

                var buffer = new byte[65536];

                while (ws.State == WebSocketState.Open && !ct.IsCancellationRequested)
                {
                    var sb = new StringBuilder();
                    WebSocketReceiveResult result;

                    do
                    {
                        result = await ws.ReceiveAsync(buffer, ct);
                        sb.Append(Encoding.UTF8.GetString(buffer, 0, result.Count));
                    }
                    while (!result.EndOfMessage);

                    if (result.MessageType == WebSocketMessageType.Close) break;

                    snapshot = Parse(sb.ToString(), symbol);
                    if (snapshot != null) yield return snapshot;
                }
            }
            catch (OperationCanceledException) { yield break; }
            catch (Exception ex)
            {
                _logger.LogWarning("WS error: {msg} — reconnecting in 3s", ex.Message);
                await Task.Delay(3000, ct);
            }
        }
    }

    private OrderBookSnapshot? Parse(string json, string symbol)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            var bids = ParseLevels(root.GetProperty("bids"), 15);
            var asks = ParseLevels(root.GetProperty("asks"), 15);

            if (bids.Count == 0 || asks.Count == 0) return null;

            var bestBid = bids[0].Price;
            var bestAsk = asks[0].Price;
            var spread  = bestAsk - bestBid;
            var spreadPct = bestBid > 0 ? spread / bestBid * 100 : 0;

            var snap = new OrderBookSnapshot
            {
                Symbol    = symbol.ToUpper(),
                Bids      = bids,
                Asks      = asks,
                LastPrice = bestBid,
                Spread    = spread,
                SpreadPct = Math.Round(spreadPct, 4),
                UpdatedAt = DateTime.UtcNow,
                Arbitrage = DetectArbitrage(symbol, bestBid, bestAsk)
            };

            _lastBestBid[symbol] = bestBid;
            _lastBestAsk[symbol] = bestAsk;

            return snap;
        }
        catch { return null; }
    }

    private static List<OrderBookEntry> ParseLevels(JsonElement arr, int take)
    {
        var result = new List<OrderBookEntry>();
        decimal cumulative = 0;

        foreach (var item in arr.EnumerateArray().Take(take))
        {
            var price  = decimal.Parse(item[0].GetString()!, System.Globalization.CultureInfo.InvariantCulture);
            var amount = decimal.Parse(item[1].GetString()!, System.Globalization.CultureInfo.InvariantCulture);
            cumulative += amount;
            result.Add(new OrderBookEntry { Price = price, Amount = amount, Total = cumulative });
        }

        return result;
    }

    // Smart Idea: simple arbitrage signal based on spread vs rolling average
    private static readonly Queue<decimal> _spreadHistory = new();

    private static ArbitrageSignal DetectArbitrage(string symbol, decimal bid, decimal ask)
    {
        var spread = ask - bid;
        var spreadPct = bid > 0 ? spread / bid * 100m : 0m;

        _spreadHistory.Enqueue(spreadPct);
        if (_spreadHistory.Count > 50) _spreadHistory.Dequeue();

        var avg = _spreadHistory.Average();
        var isAlert = spreadPct > avg * 1.5m && spreadPct > 0.05m;

        return new ArbitrageSignal
        {
            ProfitPct   = Math.Round(spreadPct, 4),
            Description = isAlert
                ? $"Wide spread detected: {spreadPct:F4}% (avg {avg:F4}%) — possible opportunity"
                : $"Normal spread: {spreadPct:F4}%",
            IsAlert = isAlert
        };
    }
}
